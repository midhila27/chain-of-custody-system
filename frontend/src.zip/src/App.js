import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import UploadEvidence from './pages/UploadEvidence';
import EvidenceList from './pages/EvidenceList';
import CustodyTransfer from './pages/CustodyTransfer';
import AuditLogs from './pages/AuditLogs';

function App() {
  return (
    <Router>
      <div style={{ background:'#0a0a0a', 
                    minHeight:'100vh', color:'#fff' }}>
        <Navbar />
        <Routes>
          <Route path="/"          element={<Dashboard />} />
          <Route path="/upload"    element={<UploadEvidence />} />
          <Route path="/evidence"  element={<EvidenceList />} />
          <Route path="/custody"   element={<CustodyTransfer />} />
          <Route path="/audit"     element={<AuditLogs />} />
        </Routes>
        <ToastContainer theme="dark" />
      </div>
    </Router>
  );
}

export default App;
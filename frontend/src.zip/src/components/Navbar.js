import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav style={{
      background:'#1a1a2e',
      padding:'0 30px',
      display:'flex',
      alignItems:'center',
      gap:'5px',
      borderBottom:'2px solid #e94560',
      flexWrap:'wrap'
    }}>
      <span style={{
        color:'#e94560',
        fontWeight:'bold',
        fontSize:'18px',
        padding:'15px 20px 15px 0',
        marginRight:'10px'
      }}>
        🔐 ChainCustody
      </span>

      {[
        { path:'/',         label:'🏠 Dashboard'        },
        { path:'/upload',   label:'📤 Upload Evidence'  },
        { path:'/evidence', label:'🗂️ Evidence List'    },
        { path:'/custody',  label:'🔗 Transfer Custody' },
        { path:'/audit',    label:'📋 Audit Logs'       },
      ].map(item => (
        <Link key={item.path} to={item.path} style={{
          color:'#ccc',
          textDecoration:'none',
          padding:'15px 12px',
          fontSize:'14px'
        }}>
          {item.label}
        </Link>
      ))}
    </nav>
  );
}
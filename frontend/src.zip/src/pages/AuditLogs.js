import React, { useEffect, useState } from 'react';
import { getAllAudit, getTamperAlerts } from '../api/api';

export default function AuditLogs() {
  const [logs, setLogs]     = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [tab, setTab]       = useState('all');

  useEffect(() => {
    getAllAudit().then(r => setLogs(r.data)).catch(()=>{});
    getTamperAlerts().then(r => setAlerts(r.data)).catch(()=>{});
  }, []);

  const display = tab === 'tamper' ? alerts : logs;

  return (
    <div style={{ padding:'30px' }}>
      <h2 style={{ color:'#ffb300' }}>📋 Audit Logs</h2>

      <div style={{ display:'flex', gap:'10px', marginBottom:'20px' }}>
        {['all','tamper'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            padding:'10px 20px', border:'none',
            borderRadius:'4px', cursor:'pointer',
            background: tab===t ? '#e94560' : '#1a1a2e',
            color:'#fff'
          }}>
            {t==='tamper' ? '🚨 Tamper Alerts' : '📋 All Logs'}
          </button>
        ))}
      </div>

      <table style={{ width:'100%', borderCollapse:'collapse' }}>
        <thead>
          <tr style={{ background:'#1a1a2e' }}>
            {['ID','Action','By','Badge','IP',
              'Evidence','Case','Time'].map(h=>(
              <th key={h} style={{
                padding:'10px', textAlign:'left',
                fontSize:'12px', color:'#aaa',
                borderBottom:'1px solid #333'
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {display.map(log=>(
            <tr key={log.id} style={{ borderBottom:'1px solid #1a1a1a' }}>
              <td style={{ padding:'10px' }}>{log.id}</td>
              <td style={{ padding:'10px' }}>
                <span style={{
                  color: log.action==='TAMPER_DETECTED'
                         ? '#ff4444' : '#44ff88',
                  fontWeight:'bold', fontSize:'12px'
                }}>
                  {log.action}
                </span>
              </td>
              <td style={{ padding:'10px', fontSize:'13px' }}>{log.performedBy}</td>
              <td style={{ padding:'10px', fontSize:'13px' }}>{log.badgeNumber}</td>
              <td style={{ padding:'10px', fontSize:'12px' }}>{log.ipAddress}</td>
              <td style={{ padding:'10px', fontSize:'13px' }}>{log.evidenceId}</td>
              <td style={{ padding:'10px', fontSize:'13px' }}>{log.caseId}</td>
              <td style={{ padding:'10px', fontSize:'11px' }}>
                {log.timestamp?.replace('T',' ').substring(0,16)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {display.length===0 &&
        <p style={{ color:'#555', textAlign:'center', marginTop:'40px' }}>
          No logs yet.
        </p>}
    </div>
  );
}
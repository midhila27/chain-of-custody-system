import React, { useState } from 'react';
import { transferCustody } from '../api/api';
import { toast } from 'react-toastify';

export default function CustodyTransfer() {
  const [form, setForm] = useState({
    evidenceId:'', caseId:'',
    fromOfficer:'', fromBadge:'',
    toOfficer:'', toBadge:'',
    location:'', purpose:'', signature:''
  });
  const [result, setResult] = useState(null);

  const inp = {
    width:'100%', padding:'10px', margin:'5px 0 13px 0',
    background:'#16213e', color:'#fff',
    border:'1px solid #4fc3f7', borderRadius:'4px',
    boxSizing:'border-box'
  };

  const handleChange = e =>
    setForm({...form, [e.target.name]: e.target.value});

  const handleSubmit = async () => {
    try {
      const res = await transferCustody(form);
      setResult(res.data);
      toast.success('Custody transferred!');
    } catch {
      toast.error('Failed! Is port 8082 running?');
    }
  };

  return (
    <div style={{ padding:'30px', maxWidth:'700px', margin:'auto' }}>
      <h2 style={{ color:'#4fc3f7' }}>🔗 Transfer Custody</h2>
      <div style={{ background:'#1a1a2e', padding:'30px', borderRadius:'10px' }}>

        <div style={{ display:'grid',
                      gridTemplateColumns:'1fr 1fr', gap:'15px' }}>
          {[
            ['evidenceId','Evidence ID','e.g. 1'],
            ['caseId','Case ID','e.g. CASE-001'],
            ['fromOfficer','From Officer','Name'],
            ['fromBadge','From Badge','Badge #'],
            ['toOfficer','To Officer','Name'],
            ['toBadge','To Badge','Badge #'],
          ].map(([name, label, ph]) => (
            <div key={name}>
              <label style={{ color:'#aaa', fontSize:'13px' }}>{label}</label>
              <input style={inp} name={name}
                     placeholder={ph} onChange={handleChange} />
            </div>
          ))}
        </div>

        <label style={{ color:'#aaa', fontSize:'13px' }}>Location</label>
        <input style={inp} name="location"
               placeholder="Transfer location"
               onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>Purpose</label>
        <input style={inp} name="purpose"
               placeholder="e.g. Forensic Analysis"
               onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>Signature Note</label>
        <input style={inp} name="signature"
               placeholder="Officer acknowledgment"
               onChange={handleChange} />

        <button onClick={handleSubmit} style={{
          width:'100%', padding:'14px',
          background:'#4fc3f7', color:'#000',
          border:'none', borderRadius:'6px',
          fontSize:'16px', fontWeight:'bold', cursor:'pointer'
        }}>
          🔗 Transfer Custody
        </button>
      </div>

      {result && (
        <div style={{
          marginTop:'20px', background:'#0a1a2a',
          border:'1px solid #4fc3f7',
          borderRadius:'10px', padding:'20px'
        }}>
          <h3 style={{ color:'#4fc3f7' }}>✅ Transfer Recorded!</h3>
          <p>🆔 Record ID: {result.id}</p>
          <p>📤 From: {result.fromOfficer} ({result.fromBadge})</p>
          <p>📥 To: {result.toOfficer} ({result.toBadge})</p>
          <p>📅 Time: {result.transferTime}</p>
          <p>🌐 IP: {result.ipAddress}</p>
        </div>
      )}
    </div>
  );
}
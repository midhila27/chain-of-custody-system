import React, { useEffect, useState } from 'react';
import { getAllEvidence } from '../api/api';

export default function Dashboard() {
  const [evidence, setEvidence] = useState([]);

  useEffect(() => {
    getAllEvidence()
      .then(r => setEvidence(r.data))
      .catch(() => {});
  }, []);

  const total    = evidence.length;
  const tampered = evidence.filter(e => e.status==='TAMPERED').length;
  const photos   = evidence.filter(e => e.evidenceType==='PHOTO').length;
  const videos   = evidence.filter(e => e.evidenceType==='VIDEO').length;

  const card = (emoji, count, label, color) => (
    <div style={{
      background:'#1a1a2e', borderRadius:'10px',
      padding:'25px', textAlign:'center',
      border:`1px solid ${color}`
    }}>
      <div style={{ fontSize:'40px' }}>{emoji}</div>
      <div style={{ fontSize:'36px', fontWeight:'bold', color }}>{count}</div>
      <div style={{ color:'#aaa', marginTop:'5px' }}>{label}</div>
    </div>
  );

  return (
    <div style={{ padding:'30px' }}>
      <h1 style={{ color:'#e94560' }}>
        🔐 Chain of Custody System
      </h1>
      <p style={{ color:'#aaa' }}>
        Digital Evidence Management — Law Enforcement
      </p>

      <div style={{
        display:'grid',
        gridTemplateColumns:'repeat(4,1fr)',
        gap:'20px', marginTop:'30px'
      }}>
        {card('🗂️', total,    'Total Evidence',  '#4fc3f7')}
        {card('⚠️', tampered, 'Tampered Files',  '#ff4444')}
        {card('📷', photos,   'Photos',          '#44ff88')}
        {card('🎥', videos,   'Videos',          '#ffb300')}
      </div>

      {tampered > 0 && (
        <div style={{
          marginTop:'30px', background:'#2a0000',
          border:'2px solid #ff4444',
          borderRadius:'10px', padding:'20px'
        }}>
          <h3 style={{ color:'#ff4444' }}>
            🚨 TAMPER ALERTS!
          </h3>
          {evidence
            .filter(e => e.status==='TAMPERED')
            .map(e => (
            <div key={e.id} style={{
              background:'#1a0000', padding:'15px',
              borderRadius:'8px', marginTop:'10px'
            }}>
              <p>📁 <b>Evidence ID:</b> {e.id} | Case: {e.caseId}</p>
              <p>👤 <b>Tampered By:</b> {e.tamperedBy}</p>
              <p>🕐 <b>Time:</b> {e.tamperedAt}</p>
              <p style={{ fontSize:'12px', color:'#ff8888' }}>
                🔍 {e.tamperDetails}
              </p>
            </div>
          ))}
        </div>
      )}

      {tampered === 0 && total > 0 && (
        <div style={{
          marginTop:'30px', background:'#0a2a0a',
          border:'1px solid #44ff88',
          borderRadius:'10px', padding:'20px'
        }}>
          <h3 style={{ color:'#44ff88' }}>
            ✅ All Evidence Intact — No Tampering Detected
          </h3>
        </div>
      )}
    </div>
  );
}
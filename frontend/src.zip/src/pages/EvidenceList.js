
import React, { useEffect, useState } from 'react';
import { getAllEvidence, checkTamper } from '../api/api';
import { toast } from 'react-toastify';

export default function EvidenceList() {
  const [list, setList]   = useState([]);
  const [name, setName]   = useState('');
  const [badge, setBadge] = useState('');

  useEffect(() => { load(); }, []);

  const load = () =>
    getAllEvidence().then(r => setList(r.data)).catch(()=>{});

  const handleCheck = async (id) => {
    if (!name || !badge) {
      toast.warn('Enter your name and badge!'); return;
    }
    try {
      const res = await checkTamper(id, name, badge);
      if (res.data.status === 'TAMPERED') {
        toast.error(`🚨 TAMPERED! By: ${res.data.tamperedBy}`);
      } else {
        toast.success('✅ File is INTACT!');
      }
      load();
    } catch {
      toast.error('Check failed!');
    }
  };

  return (
    <div style={{ padding:'30px' }}>
      <h2 style={{ color:'#e94560' }}>🗂️ Evidence List</h2>

      <div style={{ display:'flex', gap:'10px', marginBottom:'20px' }}>
        <input placeholder="Your Name" value={name}
               onChange={e => setName(e.target.value)}
               style={{ padding:'10px', background:'#16213e',
                        color:'#fff', border:'1px solid #555',
                        borderRadius:'4px', flex:1 }} />
        <input placeholder="Badge #" value={badge}
               onChange={e => setBadge(e.target.value)}
               style={{ padding:'10px', background:'#16213e',
                        color:'#fff', border:'1px solid #555',
                        borderRadius:'4px', flex:1 }} />
      </div>

      <div style={{ overflowX:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#e94560' }}>
              {['ID','Case','Type','Officer','Badge',
                'Date','Status','Check'].map(h=>(
                <th key={h} style={{ padding:'12px',
                                     textAlign:'left',
                                     fontSize:'13px' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {list.map(ev=>(
              <tr key={ev.id}
                  style={{ borderBottom:'1px solid #222',
                           background: ev.status==='TAMPERED'
                                       ? '#1a0000' : 'transparent' }}>
                <td style={{ padding:'10px' }}>{ev.id}</td>
                <td style={{ padding:'10px' }}>{ev.caseId}</td>
                <td style={{ padding:'10px' }}>
                  {ev.evidenceType==='VIDEO' ? '🎥' : '📷'} {ev.evidenceType}
                </td>
                <td style={{ padding:'10px' }}>{ev.uploadedBy}</td>
                <td style={{ padding:'10px' }}>{ev.uploadedByBadge}</td>
                <td style={{ padding:'10px', fontSize:'11px' }}>
                  {ev.uploadedAt?.replace('T',' ').substring(0,16)}
                </td>
                <td style={{ padding:'10px' }}>
                  <span style={{
                    color: ev.status==='TAMPERED' ? '#ff4444':'#44ff88',
                    fontWeight:'bold'
                  }}>
                    {ev.status==='TAMPERED' ? '🚨 TAMPERED':'✅ ACTIVE'}
                  </span>
                </td>
                <td style={{ padding:'10px' }}>
                  <button onClick={()=>handleCheck(ev.id)}
                          style={{
                            background:'#1a1a2e', color:'#e94560',
                            border:'1px solid #e94560',
                            padding:'6px 12px', borderRadius:'4px',
                            cursor:'pointer', fontSize:'12px'
                          }}>
                    🔍 Check
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {list.length===0 &&
          <p style={{ color:'#555', textAlign:'center', marginTop:'40px' }}>
            No evidence uploaded yet.
          </p>}
      </div>
    </div>
  );
}
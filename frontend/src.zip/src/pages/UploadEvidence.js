import React, { useState } from 'react';
import { uploadEvidence } from '../api/api';
import { toast } from 'react-toastify';

export default function UploadEvidence() {
  const [form, setForm] = useState({
    caseId:'', uploadedBy:'', badge:'',
    location:'', description:''
  });
  const [file, setFile]         = useState(null);
  const [preview, setPreview]   = useState(null);
  const [fileType, setFileType] = useState('');
  const [loading, setLoading]   = useState(false);
  const [result, setResult]     = useState(null);

  const inp = {
    width:'100%', padding:'10px', margin:'5px 0 14px 0',
    background:'#16213e', color:'#fff',
    border:'1px solid #e94560', borderRadius:'4px',
    boxSizing:'border-box', fontSize:'14px'
  };

  const handleChange = e =>
    setForm({...form, [e.target.name]: e.target.value});

  const handleFile = e => {
    const f = e.target.files[0];
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setFileType(f.type.startsWith('video') ? 'video' : 'image');
  };

  const handleSubmit = async () => {
    if (!file) { toast.error('Select a file!'); return; }
    if (!form.caseId || !form.uploadedBy || !form.badge) {
      toast.error('Fill all required fields!'); return;
    }
    setLoading(true);
    const fd = new FormData();
    fd.append('file', file);
    Object.entries(form).forEach(([k,v]) => fd.append(k, v));
    try {
      const res = await uploadEvidence(fd);
      setResult(res.data);
      toast.success('Evidence uploaded successfully!');
    } catch {
      toast.error('Upload failed! Is port 8081 running?');
    }
    setLoading(false);
  };

  return (
    <div style={{ padding:'30px', maxWidth:'700px', margin:'auto' }}>
      <h2 style={{ color:'#e94560' }}>📤 Upload Evidence</h2>

      <div style={{
        background:'#1a1a2e', padding:'30px', borderRadius:'10px'
      }}>
        <label style={{ color:'#aaa', fontSize:'13px' }}>Case ID *</label>
        <input style={inp} name="caseId"
               placeholder="e.g. CASE-2024-001"
               onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>Officer Name *</label>
        <input style={inp} name="uploadedBy"
               placeholder="Full Name"
               onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>Badge Number *</label>
        <input style={inp} name="badge"
               placeholder="e.g. TN-PD-4521"
               onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>Location</label>
        <input style={inp} name="location"
               placeholder="Where was evidence found?"
               onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>Description</label>
        <textarea style={{...inp, height:'70px'}}
                  name="description"
                  placeholder="Describe the evidence..."
                  onChange={handleChange} />

        <label style={{ color:'#aaa', fontSize:'13px' }}>
          📎 Select Photo or Video *
        </label>
        <input style={inp} type="file"
               accept="image/*,video/*"
               onChange={handleFile} />

        {preview && fileType==='image' && (
          <img src={preview} alt="preview" style={{
            width:'100%', borderRadius:'8px',
            marginBottom:'15px', maxHeight:'250px',
            objectFit:'cover'
          }} />
        )}
        {preview && fileType==='video' && (
          <video src={preview} controls style={{
            width:'100%', borderRadius:'8px',
            marginBottom:'15px', maxHeight:'250px'
          }} />
        )}

        <button onClick={handleSubmit} disabled={loading}
                style={{
                  width:'100%', padding:'14px',
                  background: loading ? '#555' : '#e94560',
                  color:'#fff', border:'none',
                  borderRadius:'6px', fontSize:'16px',
                  cursor: loading ? 'not-allowed' : 'pointer'
                }}>
          {loading ? '⏳ Uploading...' : '🔐 Upload Evidence'}
        </button>
      </div>

      {result && (
        <div style={{
          marginTop:'20px', background:'#0a2a0a',
          border:'1px solid #44ff88',
          borderRadius:'10px', padding:'20px'
        }}>
          <h3 style={{ color:'#44ff88' }}>✅ Uploaded!</h3>
          <p>📁 <b>ID:</b> {result.id}</p>
          <p>📋 <b>Case:</b> {result.caseId}</p>
          <p>👤 <b>By:</b> {result.uploadedBy} ({result.uploadedByBadge})</p>
          <p>🌐 <b>IP:</b> {result.uploadedByIp}</p>
          <p>🔒 <b>SHA-256:</b>
            <code style={{ fontSize:'10px',
                           wordBreak:'break-all',
                           color:'#4fc3f7' }}>
              {result.fileHash}
            </code>
          </p>
        </div>
      )}
    </div>
  );
}
